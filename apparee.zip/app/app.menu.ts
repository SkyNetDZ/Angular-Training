import { PAGES_MENU } from './pages/pages.menu';

export const MENU = [
  ...PAGES_MENU
];
