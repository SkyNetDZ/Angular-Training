export * from './baMenu.component';
