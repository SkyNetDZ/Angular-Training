export * from './baPageTop.component';
