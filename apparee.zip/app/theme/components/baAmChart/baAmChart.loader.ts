require('style-loader!ammap3/ammap/ammap.css');

require('amcharts3');
require('amcharts3/amcharts/plugins/responsive/responsive.js');
require('amcharts3/amcharts/serial.js');

require('ammap3');
require('ammap3/ammap/maps/js/worldLow');
