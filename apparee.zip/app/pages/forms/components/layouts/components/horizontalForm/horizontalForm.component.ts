import {Component} from '@angular/core';

@Component({
  selector: 'horizontal-form',
  template: require('./horizontalForm.html'),
})
export class HorizontalForm {

  constructor() {
  }
}
