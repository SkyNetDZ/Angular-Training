import {Component} from '@angular/core';

@Component({
  selector: 'without-labels-form',
  template: require('./withoutLabelsForm.html'),
})
export class WithoutLabelsForm {

  constructor() {
  }
}
