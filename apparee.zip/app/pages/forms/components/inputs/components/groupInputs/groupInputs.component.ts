import {Component} from '@angular/core';

@Component({
  selector: 'group-inputs',
  template: require('./groupInputs.html'),
})
export class GroupInputs {

  constructor() {
  }
}
