import {Component} from '@angular/core';

@Component({
  selector: 'standard-inputs',
  template: require('./standardInputs.html'),
})
export class StandardInputs {

  constructor() {
  }
}
