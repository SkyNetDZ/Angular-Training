export * from './locations.component';
