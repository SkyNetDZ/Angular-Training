/**
 * Created by Inneasoft on 23/11/2016.
 */
import {Component} from '@angular/core';

@Component({
  selector: 'aree-date-picker',
  templateUrl: './datePicker.component.html'
})
export class DatePicker {
  model;
  public label : string ;
}
