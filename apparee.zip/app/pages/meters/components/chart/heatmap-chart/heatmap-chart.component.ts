import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heatmap-chart',
  templateUrl: './heatmap-chart.component.html',
  styleUrls: ['./heatmap-chart.component.css']
})
export class HeatmapChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
