import {Component, OnInit} from "@angular/core";

@Component({
  selector: 'app-table-cell',
  templateUrl: 'table-cell.component.html',
  styleUrls: ['table-cell.component.css']
})
export class TableCellComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
