/* tslint:disable:no-unused-variable */
import {TableColumnComponent} from "./table-column.component";

describe('Component: TableColumn', () => {
  it('should create an instance', () => {
    let component = new TableColumnComponent();
    expect(component).toBeTruthy();
  });
});
