/* tslint:disable:no-unused-variable */
import {TableRowComponent} from "./table-row.component";

describe('Component: TableRow', () => {
  it('should create an instance', () => {
    let component = new TableRowComponent();
    expect(component).toBeTruthy();
  });
});
