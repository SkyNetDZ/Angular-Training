import {Component} from '@angular/core';

@Component({
  selector: 'responsive-table',
  template: require('./responsiveTable.html'),
})
export class ResponsiveTable {

  constructor() {
  }
}
