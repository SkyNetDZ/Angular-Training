import {Component} from '@angular/core';

@Component({
  selector: 'icon-buttons',
  template: require('./iconButtons.html'),
})
export class IconButtons {

  constructor() {
  }
}
