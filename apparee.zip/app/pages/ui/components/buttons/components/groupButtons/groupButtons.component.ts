import {Component} from '@angular/core';

@Component({
  selector: 'group-buttons',
  template: require('./groupButtons.html'),
})
export class GroupButtons {

  constructor() {
  }
}
