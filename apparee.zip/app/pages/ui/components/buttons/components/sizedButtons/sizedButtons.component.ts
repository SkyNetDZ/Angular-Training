import {Component} from '@angular/core';


@Component({
  selector: 'sized-buttons',
  template: require('./sizedButtons.html'),
})
export class SizedButtons {

  constructor() {
  }
}
