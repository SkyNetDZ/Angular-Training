import {Component} from '@angular/core';


@Component({
  selector: 'raised-buttons',
  template: require('./raisedButtons.html'),
})
export class RaisedButtons {

  constructor() {
  }
}
