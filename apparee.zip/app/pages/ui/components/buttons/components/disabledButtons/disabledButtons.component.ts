import { Component } from '@angular/core';


@Component({
  selector: 'disabled-buttons',
  template: require('./disabledButtons.html'),
})
export class DisabledButtons {

  constructor() {
  }
}
