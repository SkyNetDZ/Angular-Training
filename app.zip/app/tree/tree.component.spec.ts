/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TreeComponent } from './tree.component';

describe('Component: Tree', () => {
  it('should create an instance', () => {
    let component = new TreeComponent();
    expect(component).toBeTruthy();
  });
});
