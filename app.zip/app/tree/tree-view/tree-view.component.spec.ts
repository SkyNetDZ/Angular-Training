/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TreeViewComponent } from './tree-view.component';

describe('Component: TreeView', () => {
  it('should create an instance', () => {
    let component = new TreeViewComponent();
    expect(component).toBeTruthy();
  });
});
