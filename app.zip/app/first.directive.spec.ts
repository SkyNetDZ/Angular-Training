/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FirstDirective } from './first.directive';

describe('Directive: First', () => {
  it('should create an instance', () => {
    let directive = new FirstDirective();
    expect(directive).toBeTruthy();
  });
});
