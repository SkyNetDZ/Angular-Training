import { Injectable } from '@angular/core';

@Injectable()
export class SimpleService {

  message = "I'm Simple Service Shared with your widget"

  constructor() { }

}
