import { Directive, ElementRef, ViewContainerRef, TemplateRef } from '@angular/core';

@Directive({
  selector: '[first]'
})
export class FirstDirective {

  constructor(el: ElementRef,private view: ViewContainerRef, private template: TemplateRef<any>) {
    this.view.createEmbeddedView(this.template);
  }

}
