/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { LineChartComponent } from './line-chart.component';

describe('Component: LineChart', () => {
  it('should create an instance', () => {
    let component = new LineChartComponent();
    expect(component).toBeTruthy();
  });
});
