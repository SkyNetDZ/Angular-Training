/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { HeatmapChartComponent } from './heatmap-chart.component';

describe('Component: HeatmapChart', () => {
  it('should create an instance', () => {
    let component = new HeatmapChartComponent();
    expect(component).toBeTruthy();
  });
});
