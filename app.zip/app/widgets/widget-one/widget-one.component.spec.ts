/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { WidgetOneComponent } from './widget-one.component';

describe('Component: WidgetOne', () => {
  it('should create an instance', () => {
    let component = new WidgetOneComponent();
    expect(component).toBeTruthy();
  });
});
