/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { WidgetTwoComponent } from './widget-two.component';

describe('Component: WidgetTwo', () => {
  it('should create an instance', () => {
    let component = new WidgetTwoComponent();
    expect(component).toBeTruthy();
  });
});
