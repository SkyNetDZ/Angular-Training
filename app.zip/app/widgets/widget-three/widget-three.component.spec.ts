/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { WidgetThreeComponent } from './widget-three.component';

describe('Component: WidgetThree', () => {
  it('should create an instance', () => {
    let component = new WidgetThreeComponent();
    expect(component).toBeTruthy();
  });
});
