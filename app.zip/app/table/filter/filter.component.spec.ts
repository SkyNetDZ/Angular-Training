/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FilterComponent } from './filter.component';

describe('Component: Filter', () => {
  it('should create an instance', () => {
    let component = new FilterComponent();
    expect(component).toBeTruthy();
  });
});
