/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TableComponent } from './table.component';

describe('Component: Table', () => {
  it('should create an instance', () => {
    let component = new TableComponent();
    expect(component).toBeTruthy();
  });
});
