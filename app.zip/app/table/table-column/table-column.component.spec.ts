/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TableColumnComponent } from './table-column.component';

describe('Component: TableColumn', () => {
  it('should create an instance', () => {
    let component = new TableColumnComponent();
    expect(component).toBeTruthy();
  });
});
