import {
  Component, OnInit, Input, ContentChildren, QueryList, ElementRef, ViewChild,
  ViewContainerRef, TemplateRef
} from '@angular/core';
import {Directory} from "../model/Directory";
import {TableCellComponent} from "../table-cell/table-cell.component";

@Component({
  selector: 'app-table-row',
  templateUrl: 'table-row.component.html',
  styleUrls: ['table-row.component.css']
})
export class TableRowComponent {

  @Input() children: Array<Directory>;

  @Input() padding: number ;

  @ViewChild('row') template;

  @ViewChild('cell') cell ;

  @ContentChildren('row') items: QueryList<ElementRef>;

  constructor(private view : ViewContainerRef) {
  }

  ngAfterContentInit() {
    this.view.createEmbeddedView(this.template);
  }

}
