import {Component, OnInit, ContentChildren, ViewChild, ViewContainerRef} from '@angular/core';

@Component({
  selector: 'app-table-cell',
  // templateUrl: './table-cell.component.html',
  template: `<template #cell let-content="content">
  <div class="rTableCell">{{ content }}</div>
</template>`,
  styleUrls: ['./table-cell.component.css']
})
export class TableCellComponent {

  @ViewChild('cell') cell;

  constructor(private view: ViewContainerRef) {
  }

  ngAfterContentInit() {
    this.view.createEmbeddedView(this.cell);
  }
}
