/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TableCellComponent } from './table-cell.component';

describe('Component: TableCell', () => {
  it('should create an instance', () => {
    let component = new TableCellComponent();
    expect(component).toBeTruthy();
  });
});
