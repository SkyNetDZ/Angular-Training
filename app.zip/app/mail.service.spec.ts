/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { MailService } from './mail.service';

describe('Service: Mail', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MailService]
    });
  });

  it('should ...', inject([MailService], (service: MailService) => {
    expect(service).toBeTruthy();
  }));
});
